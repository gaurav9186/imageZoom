angular.module("advisor",['ngAnimate', 'ui.bootstrap','ngMessages','ngScrollable'])
